package com.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.example.config.Helper;

/**
 * JDBC
 *
 */
public class App {
	public static void main(String[] args) {
		Connection con;
		try {
			con = Helper.makeCon();
			System.out.println("Got a Connection " + con.getClass().getName());
			PreparedStatement pst = con.prepareStatement("select ename,sal from emp where deptno=?");
			pst.setInt(1, 20);
			ResultSet rs = pst.executeQuery();
			while (rs.next())
				System.out.println("ename is " + rs.getString("ename") + " sal is " + rs.getInt("sal"));

			System.out.println("-------------------------------------------");

			pst = con.prepareStatement("insert into dataset values(?,?)");
			pst.setInt(1, 20);
			pst.setString(2, "Rishin");
//			pst = con.prepareStatement("insert into dataset values(?,?)");
//			pst.setInt(2, 21);
//			pst.setString(3, "Debdeep");
			int r = pst.executeUpdate();
			if (r > 0)
				System.out.println("--------------data inserted------------");
			else
				System.out.println("--------------data not inserted------------");

			con.close();

		} catch (SQLException e) {
			System.out.println("The error is" + e);

		} catch (Exception e) {

			System.out.println("General error is" + e);

		}

	}
}
